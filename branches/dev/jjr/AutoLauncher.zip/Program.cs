using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Xml;
using System.Diagnostics;
using System.Collections;

namespace AutoLauncher
{
    class Program
    {
        static string[] SmartArguments
        {
            get
            {
                return new string[] { "Argument.ProjectPath",
                    "Argument.SolutionPath",
                    "Argument.AssemblyProjectPath",
                    "Argument.BuildMode"}; }
        }

        static protected string ScriptsDirectory
        {
            get
            {
                string path = ProjectDirectory.TrimEnd('\\') + @"\Scripts";

                return path;
            }
        }
        static private string projectPropertiesPath = String.Empty;
        static protected string ProjectPropertiesPath
        {
            get
            {
                if (projectPropertiesPath == String.Empty)
                    projectPropertiesPath = GetProjectPropertiesPath();
                return projectPropertiesPath;
            }
        }

        static private string projectDirectory = String.Empty;
        static protected string ProjectDirectory
        {
            get
            {
                if (projectDirectory == String.Empty)
                    projectDirectory = Path.GetDirectoryName(ProjectPropertiesPath);
                return projectDirectory;
            }
        }

        static private string solutionDirectory = String.Empty;
        static protected string SolutionDirectory
        {
            get
            {
                if (solutionDirectory == String.Empty)
                    solutionDirectory = GetSolutionDirectory(ProjectDirectory);
                return solutionDirectory;
            }
            set { solutionDirectory = value; }
        }

        static protected string NAntPath
        {
            get
            {
               /* string path = Path.GetDirectoryName(System.Reflection.Assembly.GetEntryAssembly().Location);

                string alternativePath = Path.GetDirectoryName(path.Replace(Path.GetFileName(path), String.Empty).Replace(@"AutoLauncher\bin\", String.Empty));

                path += @"\Lib\nant\nant.exe";
                alternativePath += @"\Lib\nant\nant.exe";

                if (Directory.Exists(path))
                    return path;
                else
                    return alternativePath;*/

                return ProjectDirectory + @"\Lib\nant\nant";
            }
        }

        static private string[] assemblyProjectPaths;
        static protected string[] AssemblyProjectPaths
        {
            get
            {
                if (assemblyProjectPaths == null || assemblyProjectPaths.Length == 0)
                    assemblyProjectPaths = GetAssemblyProjectPaths(SolutionDirectory);
                return assemblyProjectPaths;
            }
        }

        static private string[] solutionPaths;
        static protected string[] SolutionPaths
        {
            get
            {
                if (solutionPaths == null || solutionPaths.Length == 0)
                    solutionPaths = GetSolutionPaths(ProjectDirectory);
                return solutionPaths;
            }
        }


        static protected Dictionary<int, string> AvailableCommands = null;

        static void Main(string[] args)
        {
            ListCommands();
        }

        static private void ListCommands()
        {
            AvailableCommands = GetStartCommands();

            Console.WriteLine(" ");
            Console.WriteLine("----------------------------------------");

            Console.WriteLine(" ");

            Console.WriteLine("== Commands:");
            Console.WriteLine(" ");

            Console.WriteLine("0: Exit");

            foreach (int i in AvailableCommands.Keys)
            {
                XmlDocument doc = LoadDocument(AvailableCommands[i]);

                string startFileSummary = GetSummary(doc);


                Console.WriteLine(i + ": " + startFileSummary);

                doc = null;
            }

            Console.WriteLine(" ");

            Console.WriteLine("----------------------------------------");

            Console.WriteLine(" ");

            Console.WriteLine("Choose command:");

            string input = Console.ReadLine();
            int commandNumber = 0;

            if (Int32.TryParse(input, out commandNumber) && commandNumber > 0 && commandNumber < AvailableCommands.Keys.Count)
                StartCommand(commandNumber);
            else
                InvalidCommand(input);
        }

        static private void StartCommand(int commandNumber)
        {
            if (commandNumber != 0)
            {
                XmlDocument doc = LoadDocument(AvailableCommands[commandNumber]);

                string argumentsString = GetArgumentsString(doc);

                Console.WriteLine(" ");

                Console.WriteLine("----------------------------------------");


                Console.WriteLine("Executing NANT script: " + AvailableCommands[commandNumber]);


                ProcessStartInfo info = new ProcessStartInfo(NAntPath, "-buildfile:" + AvailableCommands[commandNumber] + " " + argumentsString);

                //info.FileName = NAntPath;
                //info.Arguments = "-buildfile:" + AvailableCommands[commandNumber] + " " + argumentsString;
                info.UseShellExecute = false;
                info.RedirectStandardOutput = true;
                info.RedirectStandardError = true;
                info.RedirectStandardInput = true;
               // info.CreateNoWindow = false;
               // info.ErrorDialog = true;
                /*info.UseShellExecute = true;
                info.RedirectStandardOutput = true;
                info.RedirectStandardError = true;
                info.RedirectStandardInput = true;*/
                //info.CreateNoWindow = false;
                info.ErrorDialog = true;
                //nant.StartInfo.UseShellExecute = true;
                //nant.StartInfo.RedirectStandardOutput = true;
                //nant.
                //nant.



                Process processChild = Process.Start(info); // separate window


               // processChild.OutputDataReceived += new DataReceivedEventHandler(nant_OutputDataReceived);
               // processChild.ErrorDataReceived += new DataReceivedEventHandler(nant_ErrorDataReceived);

                //processChild.WaitForExit();
                Console.Write(processChild.StandardOutput.ReadToEnd());

              //  while (processChild.StandardError.Peek() > 0)
                    Console.Write(processChild.StandardError.ReadToEnd());

                
                //Console.WriteLine(nant.StandardOutput.ReadToEnd());
                //Console.WriteLine(nant.StandardError.ReadToEnd());
 

                //nant.WaitForExit();


                //Console.WriteLine(processChild.StandardError.ReadToEnd());
                //Console.WriteLine(processChild.StandardOutput.ReadToEnd());
                //Console.WriteLine(nant.StandardInput.ReadToEnd());


                //nant.WaitForExit();

                Console.WriteLine("----------------------------------------");

                Console.WriteLine(" ");


                ListOrClose();
            }
        }

        static void nant_ErrorDataReceived(object sender, DataReceivedEventArgs e)
        {
            Console.Write(e.Data);
        }

        static void nant_OutputDataReceived(object sender, DataReceivedEventArgs e)
        {
            Console.Write(e.Data);
        }

        static private void ListOrClose()
        {
            Console.WriteLine("Would you like to perform another operation?");

            string input = Console.ReadLine();

            if (input.ToLower() == "y" || input.ToLower() == "yes")
                ListCommands();                
        }

        static private void InvalidCommand(string input)
        {
            Console.WriteLine("Invalid command: " + input);

            ListCommands();
        }

        static private Dictionary<int, string> GetStartCommands()
        {
            Dictionary<int, string> availableCommands = new Dictionary<int, string>();

            Console.WriteLine("Using scripts directory: " + ScriptsDirectory);

            int i = 0;
            foreach (string startFile in Directory.GetFiles(ScriptsDirectory, "Common.Start.*.nant"))
            {
                i++;

                availableCommands.Add(i, startFile);
            }

            return availableCommands;
        }

        static private XmlDocument LoadDocument(string fileName)
        {
            XmlDocument doc = new XmlDocument();
            doc.Load(fileName);

            return doc;
        }

        static private string GetSummary(XmlDocument doc)
        {
            string name = GetName(doc);
            string description = GetDescription(doc);

            XmlElement node = (XmlElement)doc.DocumentElement.ChildNodes[0];

            return name + " - " + description;
        }

        static private string GetName(XmlDocument doc)
        {
            string name = String.Empty;

            if (doc.DocumentElement.HasChildNodes)
            {
                foreach (XmlNode node in doc.DocumentElement.ChildNodes)
                {
                    if (node != null && node is XmlElement && ((XmlElement)node).Name.ToLower() == "target" && ((XmlElement)node).HasAttribute("name"))
                    {
                        name = ((XmlElement)node).Attributes["name"].Value;

                        name = name.Replace("Common.Start.", String.Empty);

                        break;
                    }
                }
            }
            return name;
        }


        static private string GetDescription(XmlDocument doc)
        {
            string description = String.Empty;

            if (doc.DocumentElement.HasChildNodes)
            {
                foreach (XmlNode node in doc.DocumentElement.ChildNodes)
                {
                    if (node != null && node is XmlElement && ((XmlElement)node).Name.ToLower() == "target" && ((XmlElement)node).HasAttribute("description"))
                    {
                        description = ((XmlElement)node).Attributes["description"].Value;

                        break;
                    }
                }
            }
            return description;
        }

        static private string[] GetArgumentNames(XmlDocument doc)
        {
            string name = String.Empty;

            ArrayList list = new ArrayList();
            if (doc.DocumentElement.HasChildNodes)
            {
                foreach (XmlNode node in doc.DocumentElement.ChildNodes)
                {
                    /*if (node != null && node is XmlElement && ((XmlElement)node).HasAttribute("name"))
                    {
                        name = ((XmlElement)node).Attributes["name"].Value;

                        name = name.Replace("Common.Start.", String.Empty);
                    }*/
                    if (node != null && node is XmlElement
                        && ((XmlElement)node).Name.ToLower() == "property"
                        && ((XmlElement)node).HasAttribute("name"))
                    {
                        
                        string propertyName = String.Empty;

                        if (((XmlElement)node).HasAttribute("name"))
                            propertyName = ((XmlElement)node).Attributes["name"].Value;

                        if (Array.IndexOf(SmartArguments, propertyName) > -1)
                        {
                            list.Add(propertyName);
                        }
                    }
                }
            }
            return (string[])list.ToArray(typeof(string));
        }

        static private string GetArgumentsString(XmlDocument doc)
        {
            string argumentsString = String.Empty;
            foreach (string argument in GetArgumentNames(doc))
            {
                if (argument == "Argument.SolutionPath")
                {
                    string value = InputSolutionPath();

                    SolutionDirectory = Path.GetDirectoryName(value);

                    //value = value.Replace(SolutionDirectory, String.Empty);
                    if (argumentsString.Length > 0)
                        argumentsString += " ";
                    argumentsString += "-D:" + argument + "=" + value;
                }
                if (argument == "Argument.AssemblyProjectPath")
                {
                    string value = InputAssemblyProjectPath();

                    //value = value.Replace(SolutionDirectory, String.Empty);
                    if (argumentsString.Length > 0)
                        argumentsString += " ";
                    argumentsString += "-D:" + argument + "=" + value;
                }
                if (argument == "Argument.ProjectPath")
                {
                    string value = ProjectPropertiesPath;

                    //value = value.Replace(SolutionDirectory, String.Empty);
                    if (argumentsString.Length > 0)
                        argumentsString += " ";
                    argumentsString += "-D:" + argument + "=" + value;
                }
                if (argument == "Argument.BuildMode")
                {
                    string value = InputBuildMode();
                    //value = value.Replace(SolutionDirectory, String.Empty);
                    if (argumentsString.Length > 0)
                        argumentsString += " ";
                    argumentsString += "-D:" + argument + "=" + value;
                }
            }

            return argumentsString;
        }

        static private string[] GetAssemblyProjectPaths(string rootPath)
        {
            ArrayList list = new ArrayList();

            foreach (string file in Directory.GetFiles(rootPath, "*.Assembly.nant"))
            {
                //.Replace(Path.GetFileName(file), String.Empty)
                list.Add(file);//.Replace(SolutionDirectory, String.Empty).Trim('\\'));
            }

            foreach (string directory in Directory.GetDirectories(rootPath))
            {
                list.AddRange(GetAssemblyProjectPaths(directory));
            }

            return (string[])list.ToArray(typeof(string));
        }


        static private string[] GetSolutionPaths(string rootPath)
        {
            ArrayList list = new ArrayList();

            foreach (string file in Directory.GetFiles(rootPath, "*.Solution.nant"))
            {
                //.Replace(Path.GetFileName(file), String.Empty)
                list.Add(file);//.Replace(SolutionDirectory, String.Empty).Trim('\\'));
            }

            foreach (string directory in Directory.GetDirectories(rootPath))
            {
                list.AddRange(GetSolutionPaths(directory));
            }

            return (string[])list.ToArray(typeof(string));
        }

        static private string InputAssemblyProjectPath()
        {
            string path;

            Console.WriteLine(" ");
            Console.WriteLine("----------------------------------------");

            Console.WriteLine(" ");

            Console.WriteLine("== Assembly projects:");
            Console.WriteLine(" ");

            int i = 0;

            foreach (string projectPath in AssemblyProjectPaths)
            {
                i++;
                //XmlDocument doc = LoadDocument(AvailableCommands[i]);

                //string startFileSummary = GetSummary(doc);


                Console.WriteLine(i + ": " + projectPath.Replace(SolutionDirectory, String.Empty).Trim('\\').Replace(Path.GetFileName(projectPath), String.Empty));

                //doc = null;
            }

            Console.WriteLine(" ");

            Console.WriteLine("----------------------------------------");

            Console.WriteLine(" ");

            Console.WriteLine("Choose assembly project:");

            string input = Console.ReadLine();
            int commandNumber = 0;

            if (!Int32.TryParse(input, out commandNumber) || commandNumber < 0 || commandNumber >= AvailableCommands.Keys.Count)
                InvalidCommand(input);

            return AssemblyProjectPaths[commandNumber-1];
        }

        static private string InputSolutionPath()
        {

            Console.WriteLine(" ");
            Console.WriteLine("----------------------------------------");

            Console.WriteLine(" ");

            Console.WriteLine("== Solutions:");
            Console.WriteLine(" ");

            int i = 0;

            foreach (string solutionPath in SolutionPaths)
            {
                i++;
                //XmlDocument doc = LoadDocument(AvailableCommands[i]);

                //string startFileSummary = GetSummary(doc);


                Console.WriteLine(i + ": " + solutionPath.Replace(ProjectDirectory, String.Empty).Trim('\\').Replace(Path.GetFileName(solutionPath), String.Empty));

                //doc = null;
            }

            Console.WriteLine(" ");

            Console.WriteLine("----------------------------------------");

            Console.WriteLine(" ");

            Console.WriteLine("Choose solution:");

            string input = Console.ReadLine();
            int commandNumber = 0;

            if (!Int32.TryParse(input, out commandNumber) || commandNumber < 0 || commandNumber >= AvailableCommands.Keys.Count)
                InvalidCommand(input);

            return SolutionPaths[commandNumber - 1];
        }


        static private string InputBuildMode()
        {
            string path;

            Console.WriteLine(" ");
            Console.WriteLine("----------------------------------------");

            Console.WriteLine(" ");

            Console.WriteLine("== Build mode:");
            Console.WriteLine(" ");

            
                Console.WriteLine("1: Release");
                Console.WriteLine("2: Debug");

            Console.WriteLine(" ");

            Console.WriteLine("----------------------------------------");

            Console.WriteLine(" ");

            Console.WriteLine("Choose build mode:");

            string input = Console.ReadLine();
            int commandNumber = 0;

            if (!Int32.TryParse(input, out commandNumber)
                 || commandNumber < 0 || commandNumber >= AvailableCommands.Keys.Count)
            {
                InvalidCommand(input);
            }

            if (commandNumber == 1)
                return "Release";
            else
                return "Debug";
        }

        private static string GetSolutionDirectory(string startingPath)
        {
            //Console.WriteLine("Looking for solution file in: " + startingPath);

            string path = startingPath;
            string finalPath = String.Empty;
            
            foreach (string file in Directory.GetFiles(path, @"*.Solution.nant"))
                finalPath = path;

            foreach (string directory in Directory.GetDirectories(startingPath))
            {
                if (directory.IndexOf(".svn") == -1)
                {
                    foreach (string file in Directory.GetFiles(directory, @"*.Solution.nant"))
                    {
                        finalPath = directory;
                        return finalPath;
                    }

                    finalPath = GetSolutionDirectory(directory);
                }
            }

            return finalPath;
        }

        private static string GetProjectPropertiesPath()
        {
            string path = Path.GetDirectoryName(System.Reflection.Assembly.GetEntryAssembly().Location);
            string finalPath = String.Empty;

            foreach (string file in Directory.GetFiles(path, @"*.Project.nant"))
            {
                finalPath = file;
            }

            return finalPath;
        }

    }
}
